package com.uclient.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.uclient.app.databinding.ActivityMainBinding
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Launcher seçenekleri: görünen isim -> gerçek Android paket adı.
    // "Özel paket adı..." seçilince kullanıcı kendi paket adını yazabilir.
    private val launcherOptions = listOf(
        "Minecraft (Resmi)" to "com.mojang.minecraftpe",
        "Minecraft Preview" to "com.mojang.minecraftpebeta",
        "Özel paket adı..." to null
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val labels = launcherOptions.map { it.first }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        binding.launcherSpinner.adapter = adapter

        binding.launcherSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val isCustom = launcherOptions[position].second == null
                binding.customPackageInput.visibility = if (isCustom) View.VISIBLE else View.GONE
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        binding.startButton.setOnClickListener { launchSelectedMinecraft() }
        binding.importButton.setOnClickListener { importResourcePack() }
    }

    private fun launchSelectedMinecraft() {
        val position = binding.launcherSpinner.selectedItemPosition
        val preset = launcherOptions[position].second
        val packageName = preset ?: binding.customPackageInput.text.toString().trim()

        if (packageName.isEmpty()) {
            Toast.makeText(this, R.string.custom_package_hint, Toast.LENGTH_SHORT).show()
            return
        }

        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            Toast.makeText(this, R.string.opening, Toast.LENGTH_SHORT).show()
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, R.string.not_installed, Toast.LENGTH_LONG).show()
        }
    }

    private fun importResourcePack() {
        try {
            val packDir = File(cacheDir, "pack")
            if (!packDir.exists()) packDir.mkdirs()
            val outFile = File(packDir, "Uclient.mcpack")

            assets.open("Uclient.mcpack").use { input ->
                FileOutputStream(outFile).use { output ->
                    input.copyTo(output)
                }
            }

            val uri: Uri = FileProvider.getUriForFile(
                this,
                "com.uclient.app.fileprovider",
                outFile
            )

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/mcpack")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.pack_missing) + ": ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
