# Uclient Launcher (Android APK kaynak kodu)

Bu, Kotlin ile yazılmış tam bir Android Studio projesidir. Ekranda:
- **Launcher seç**: "Minecraft (Resmi)", "Minecraft Preview" veya kendi
  paket adını yazabileceğin "Özel paket adı..." seçeneği.
- **BAŞLAT**: seçtiğin Minecraft sürümünü telefonunda açar (gerçekten
  çalışan tek özellik budur — bir launcher'ın görevi zaten bu).
- **Kaynak Paketini İçe Aktar**: bir önceki adımda yaptığımız `Uclient.mcpack`
  dosyasını uygulamanın içine gömdüm; bu düğme onu Minecraft'a aktarım
  ekranına gönderir.

## Önemli: elimde derlenmiş .apk yok, kaynak kod var
Bu sohbetin çalıştığı ortamda internet bağlantısı ve Android SDK/Gradle
yüklü değil — yani gerçek bir `.apk` dosyasını burada derleyip
imzalayamıyorum. Bunun yerine **GitHub'tan gerçekten .apk üretecek**,
eksiksiz ve derlenebilir bir proje hazırladım. İki yoldan biriyle .apk'yi
alabilirsin:

### Yol 1 — GitHub Actions (kodlama bilmeden, önerilen)
1. Bu klasörü yeni bir GitHub reposuna yükle (GitHub'ta "New repository" →
   dosyaları sürükle-bırak veya `git push`).
2. Repo'nun **Actions** sekmesine git — `Build Uclient APK` iş akışı
   otomatik başlar (push ettiğinde tetiklenir, veya "Run workflow" ile
   elle de başlatabilirsin).
3. İş bitince (birkaç dakika sürer) çalışan işin sayfasında
   **Artifacts** kısmından `Uclient-debug-apk` dosyasını indir — içinde
   kurulabilir `app-debug.apk` var.
4. Bu apk'yi telefonuna aktarıp "bilinmeyen kaynaklara izin ver"
   diyerek kurabilirsin.

### Yol 2 — Android Studio (yerelde)
1. Ücretsiz [Android Studio](https://developer.android.com/studio) kur.
2. "Open" ile bu proje klasörünü aç, Gradle senkronizasyonunun
   bitmesini bekle (internet ister, bağımlılıkları indirir).
3. Üstten **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. `app/build/outputs/apk/debug/app-debug.apk` oluşur.

## Paket adı / uygulama adı
- Uygulama adı: **Uclient**
- Android paket adı (applicationId): `com.uclient.app`

## Not
`Minecraft (Resmi)` ve `Minecraft Preview` seçenekleri gerçek, herkese açık
Android paket adlarını kullanır (`com.mojang.minecraftpe`,
`com.mojang.minecraftpebeta`). Uygulama sadece `startActivity` ile bu
uygulamaları açar; hiçbir şekilde hack/inject yapmaz.
